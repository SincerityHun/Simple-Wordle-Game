package edu.skku.cs.pa1

class wordList (
    val word: List<Char>, //word list
    val color: List<Int>, //color version 0:gray ,1:yellow ,2: green
    )