package edu.skku.cs.pa1

class letterList (
    val letter:String,
    val type:Int, //0: Gray, 1: yellow, 2: Green
    )